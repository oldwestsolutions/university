export default function EnrollmentLayout({ children }) {
  return <>{children}</>;
} 